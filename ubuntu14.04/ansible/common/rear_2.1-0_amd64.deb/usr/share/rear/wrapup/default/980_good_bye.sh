### Indicate successful recovery
###

Print "Finished recovering your system. You can explore it under '$TARGET_FS_ROOT'."
